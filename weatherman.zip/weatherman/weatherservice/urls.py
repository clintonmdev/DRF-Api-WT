from django.urls import path
from weatherservice import views

app_name='weatherservice'

urlpatterns = [
    path('forecast/<city>', views.home, name='home'),
    path('forecast/', views.forecast, name='forecast'),
    path('ping/', views.ping, name='ping'),
]

