from django.apps import AppConfig


class WeatherserviceConfig(AppConfig):
    name = 'weatherservice'
