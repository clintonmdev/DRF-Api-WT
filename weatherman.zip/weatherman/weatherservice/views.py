from django.conf import settings
from django.shortcuts import render
from django.http import JsonResponse
import json
import requests




appid = settings.API_KEY

def home(request, city):
    try:
        r = requests.get('http://api.openweathermap.org/data/2.5/weather?q={city}&appid={appid}'.format(city=city, appid=appid))
        content = r.json()
        data = {
            'clouds': content['weather'][0]['description'],
            'humidity': str(content['main']['humidity']) + "%" ,
            'pressure': str(content['main']['pressure']) + " hPa",
            'temperature': str( "%.1f" % ((content['main']['temp']) - 273.15)) + "C",
        }
        status = 200
    except KeyError:
        data = {
                "error": "Cannot find city " + str(city),
                "error_code": "city not found"
        }
        status=404
    except Exception:
        data = {
            "error": "something went wrong",
            "error_code": "internal server error"
        }
        status=500

    finally:
        if r.status_code == 401:
            data = 'Invalid API key'
            return JsonResponse(data, safe=False, status=r.status_code)

    return JsonResponse(data, json_dumps_params={'indent': ' '}, safe=False, status=status)


def forecast(requests):
    data = {
            "error": "no city provided",
            "error_code": "invalid request"
    }
    return JsonResponse(data,json_dumps_params={'indent': ' '}, safe=False, status=400, )


def ping(request):
    try:
        with open('VERSION', 'r') as f:
            version = f.read()
        
        print(version)
        data = {
            "name": "weatherservice",
            "status": "ok",
            "version": version.rstrip()
        }
    except Exception:
        data = "Something went wrong ..."

    return JsonResponse(data,json_dumps_params={'indent': ' '}, safe=False)
