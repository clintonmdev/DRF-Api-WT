from django.test import SimpleTestCase
from django.urls import reverse, resolve
from weatherservice.views import home, forecast, ping

class TestUrls(SimpleTestCase):
    
    def test_home_url_resolves(self):
        url = reverse('weatherservice:home', args=['paris'])
        print(resolve(url))
        self.assertEqual(resolve(url).func, home)

    def test_forecast_url_resolves(self):
        url = reverse('weatherservice:forecast')
        print(resolve(url))
        self.assertEqual(resolve(url).func, forecast)

    def test_ping_url_resolves(self):
        url = reverse('weatherservice:ping')
        print(resolve(url))
        self.assertEqual(resolve(url).func, ping)